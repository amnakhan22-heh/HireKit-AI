<#
.SYNOPSIS
  Authorized Windows VM security baseline and GitHub egress assessment.
.DESCRIPTION
  PowerShell 5.1+; runs without administrator privileges where possible.
  Default: read-only local checks. The script NEVER reads secret contents,
  dumps credentials, changes firewall rules, stops processes, scans other hosts,
  or uploads real company files.

  Optional -RunEgressChecks: outbound DNS/TCP and HTTP HEAD checks to known hosts.
  Optional -AllowCanaryPush -CanaryRepoUrl: creates a FRESH synthetic-only Git
  repository and attempts one push to the explicitly approved test repository.
  The push never reads any existing project folder.

  NOTE: Use an NOC-approved ENTERPRISE repository to distribute THIS script.
  Do not use a personal repository to distribute the script unless authorized.
  Check with NOC before enabling external connections or the canary push.

.EXAMPLE
  .\VM_Red_Team_Audit.ps1
.EXAMPLE
  .\VM_Red_Team_Audit.ps1 -RunEgressChecks -EnterpriseGitHost github.company.example
.EXAMPLE
  .\VM_Red_Team_Audit.ps1 -RunEgressChecks -AllowCanaryPush `
    -CanaryRepoUrl https://github.com/APPROVED-TEST-ACCOUNT/APPROVED-PRIVATE-REPO.git

  Outputs are saved under the current user's TEMP folder by default.
  Do not publish the resulting reports publicly: they describe your VM.
#>

[CmdletBinding()]
param(
    [string]$OutputDir = (Join-Path $env:TEMP ("VM_RedTeam_Audit_{0}" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))),
    [switch]$RunEgressChecks,
    [string]$EnterpriseGitHost = '',
    [switch]$AllowCanaryPush,
    [string]$CanaryRepoUrl = ''
)

$ErrorActionPreference = 'Stop'
$script:Results = New-Object 'System.Collections.Generic.List[object]'
$script:Ports = @()
$script:Started = Get-Date

function Add-Result {
    param([string]$Area, [string]$Check, [string]$Status, [string]$Detail, [string]$Action = '')
    $script:Results.Add([pscustomobject]@{
        Time = (Get-Date).ToString('s')
        Area = $Area
        Check = $Check
        Status = $Status
        Detail = $Detail
        Recommendation = $Action
    })
    Write-Host ('[{0}] {1} - {2}' -f $Status, $Area, $Check)
}

function Test-TcpWithTimeout {
    param([string]$HostName, [int]$Port, [int]$TimeoutMs = 3500)
    $client = New-Object System.Net.Sockets.TcpClient
    $async = $null
    try {
        $async = $client.BeginConnect($HostName, $Port, $null, $null)
        if (-not $async.AsyncWaitHandle.WaitOne($TimeoutMs, $false)) {
            return 'Timeout'
        }
        $client.EndConnect($async)
        return 'Connected'
    } catch {
        return 'Not connected'
    } finally {
        if ($null -ne $async) { $async.AsyncWaitHandle.Close() }
        $client.Close()
    }
}

function Get-RegValueText {
    param([string]$Path, [string]$Name)
    try {
        if (-not (Test-Path -LiteralPath $Path)) { return 'Not configured' }
        $value = (Get-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction Stop).$Name
        if ($null -eq $value) { return 'Not configured' }
        return [string]$value
    } catch {
        return 'Not configured or not readable'
    }
}

function Get-ToolVersion {
    param([string]$CommandName, [string]$VersionArg = '--version')
    $cmd = Get-Command $CommandName -ErrorAction SilentlyContinue
    if ($null -eq $cmd) { return 'Not found on PATH' }
    try {
        $text = (& $CommandName $VersionArg 2>&1 | Out-String).Trim()
        if ($text.Length -gt 160) { $text = $text.Substring(0,160) }
        if ($text) { return $text }
        return 'Found'
    } catch {
        return 'Found; version unavailable'
    }
}

function Safe-Run {
    param([string]$Area, [string]$Check, [scriptblock]$Work)
    try { & $Work } catch {
        Add-Result $Area $Check 'UNAVAILABLE' $_.Exception.Message 'Review privileges and supported Windows edition; do not elevate without permission.'
    }
}

if ($AllowCanaryPush -and [string]::IsNullOrWhiteSpace($CanaryRepoUrl)) {
    throw 'To enable a synthetic push you must supply -CanaryRepoUrl with an approved private GitHub test repo.'
}
if ($CanaryRepoUrl -and -not $AllowCanaryPush) {
    throw 'A repository URL was supplied but no push consent switch was given. Add -AllowCanaryPush only if NOC approved this exact destination.'
}
if ($AllowCanaryPush -and $CanaryRepoUrl -notmatch '^https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+(?:\.git)?/?$') {
    throw 'CanaryRepoUrl must be a plain https://github.com/OWNER/REPO.git URL, without embedded usernames, passwords, or tokens.'
}
if ($EnterpriseGitHost -and $EnterpriseGitHost -notmatch '^[A-Za-z0-9][A-Za-z0-9.-]*[A-Za-z0-9]$') {
    throw 'EnterpriseGitHost must be a hostname, not a URL or command.'
}

New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
$OutputDir = (Resolve-Path -LiteralPath $OutputDir).Path
Write-Host "`n=== Authorized VM Red-Team Assessment ===" -ForegroundColor Cyan
Write-Host "Local report folder: $OutputDir"
Write-Host 'DEFAULT: read-only local inspection. External probes and canary push are opt-in.'

# 1. Identity, OS, and basic security context.
Safe-Run 'Identity' 'Current account' {
    $account = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    Add-Result 'Identity' 'Current account' 'INFO' $account
}
Safe-Run 'Identity' 'Elevated administrator token' {
    $principal = New-Object System.Security.Principal.WindowsPrincipal([System.Security.Principal.WindowsIdentity]::GetCurrent())
    $isAdmin = $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    Add-Result 'Identity' 'Elevated administrator token' 'INFO' "Elevated admin: $isAdmin" 'For routine developer work, use a standard user token.'
}
Safe-Run 'Host' 'Windows version and update date' {
    $os = Get-CimInstance Win32_OperatingSystem
    $detail = ('{0}; version {1}; build {2}; last boot {3}' -f $os.Caption, $os.Version, $os.BuildNumber, $os.LastBootUpTime)
    Add-Result 'Host' 'Windows version and update date' 'INFO' $detail 'Compare against company-approved supported versions.'
}
Safe-Run 'Host' 'Recent installed Windows hotfix' {
    $fix = Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 1
    if ($fix) {
        Add-Result 'Host' 'Recent installed Windows hotfix' 'INFO' ("$($fix.HotFixID); installed $($fix.InstalledOn)") 'Patch status requires NOC validation, not just the latest hotfix date.'
    } else {
        Add-Result 'Host' 'Recent installed Windows hotfix' 'UNAVAILABLE' 'No hotfix data returned'
    }
}
Safe-Run 'Host' 'Local administrators group' {
    if (Get-Command Get-LocalGroupMember -ErrorAction SilentlyContinue) {
        $members = @(Get-LocalGroupMember -Group 'Administrators' -ErrorAction Stop)
        Add-Result 'Host' 'Local administrators group' 'REVIEW' ("Members: $($members.Count). Names intentionally not exported.") 'NOC should compare local administrator members against its approved list.'
    } else { Add-Result 'Host' 'Local administrators group' 'UNAVAILABLE' 'Get-LocalGroupMember cmdlet unavailable' }
}

# 2. Firewall, RDP, clipboard and remote management.
Safe-Run 'Firewall' 'Windows firewall profiles' {
    $profiles = @(Get-NetFirewallProfile | Select-Object Name, Enabled, DefaultInboundAction, DefaultOutboundAction)
    foreach ($p in $profiles) {
        $state = if ($p.Enabled) { 'INFO' } else { 'REVIEW' }
        Add-Result 'Firewall' ("$($p.Name) profile") $state ("Enabled=$($p.Enabled); inbound=$($p.DefaultInboundAction); outbound=$($p.DefaultOutboundAction)") 'Firewall enabled does not prove restrictive egress rules; inspect effective policy with NOC.'
    }
}
Safe-Run 'RDP' 'RDP enabled on server' {
    $val = Get-RegValueText 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' 'fDenyTSConnections'
    Add-Result 'RDP' 'Remote Desktop allowed' 'INFO' ("fDenyTSConnections=$val (0=allowed, 1=blocked)")
}
Safe-Run 'RDP' 'Network Level Authentication' {
    $val = Get-RegValueText 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' 'UserAuthentication'
    $status = if ($val -eq '0') { 'REVIEW' } else { 'INFO' }
    Add-Result 'RDP' 'Network Level Authentication' $status ("UserAuthentication=$val (1=required)") 'Verify NLA and MFA/gateway policy with NOC.'
}
Safe-Run 'RDP' 'Clipboard redirection policy' {
    $paths = @('HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services','HKCU:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services')
    foreach ($path in $paths) {
        $val = Get-RegValueText $path 'fDisableClip'
        Add-Result 'RDP' ("Clipboard policy ($($path.Substring(0,4)))") 'INFO' ("fDisableClip=$val (1=blocked; absent is inconclusive)") 'A client set to bidirectional can still be blocked by server policy.'
    }
}
Safe-Run 'RDP' 'Drive redirection policy' {
    $val = Get-RegValueText 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' 'fDisableCdm'
    Add-Result 'RDP' 'Drive redirection policy' 'INFO' ("fDisableCdm=$val (1=blocked)")
}
Safe-Run 'RDP' 'Clipboard process' {
    $p = @(Get-Process rdpclip -ErrorAction SilentlyContinue)
    Add-Result 'RDP' 'Clipboard process' 'INFO' ("Running processes: $($p.Count). No processes were stopped.")
}
Safe-Run 'Remote management' 'WinRM service' {
    $service = Get-Service WinRM -ErrorAction Stop
    Add-Result 'Remote management' 'WinRM service' 'INFO' ("Status=$($service.Status); StartType=$($service.StartType)") 'Confirm WinRM is required and network-restricted.'
}
Safe-Run 'Remote management' 'SMB1 server setting' {
    if (Get-Command Get-SmbServerConfiguration -ErrorAction SilentlyContinue) {
        $smb = Get-SmbServerConfiguration -ErrorAction Stop
        $status = if ($smb.EnableSMB1Protocol) { 'REVIEW' } else { 'INFO' }
        Add-Result 'Remote management' 'SMB1 server setting' $status "EnableSMB1Protocol=$($smb.EnableSMB1Protocol)" 'Disable SMB1 unless explicitly needed and risk accepted.'
    } else { Add-Result 'Remote management' 'SMB1 server setting' 'UNAVAILABLE' 'SMB cmdlets unavailable' }
}

# 3. Endpoint protection and logging.
Safe-Run 'Endpoint' 'Microsoft Defender health' {
    if (Get-Command Get-MpComputerStatus -ErrorAction SilentlyContinue) {
        $mp = Get-MpComputerStatus -ErrorAction Stop
        Add-Result 'Endpoint' 'Microsoft Defender health' 'INFO' ("AMServiceEnabled=$($mp.AMServiceEnabled); RealTimeProtectionEnabled=$($mp.RealTimeProtectionEnabled); AntivirusEnabled=$($mp.AntivirusEnabled)") 'A different corporate EDR may be responsible for protection; confirm with NOC.'
    } else { Add-Result 'Endpoint' 'Microsoft Defender health' 'UNAVAILABLE' 'Defender cmdlet unavailable; alternative EDR may be installed.' }
}
Safe-Run 'Logging' 'PowerShell script block logging policy' {
    $v = Get-RegValueText 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging' 'EnableScriptBlockLogging'
    Add-Result 'Logging' 'PowerShell script block logging policy' 'INFO' ("EnableScriptBlockLogging=$v (1=enabled)") 'Review enterprise telemetry requirements.'
}
Safe-Run 'Logging' 'PowerShell transcription policy' {
    $v = Get-RegValueText 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription' 'EnableTranscripting'
    Add-Result 'Logging' 'PowerShell transcription policy' 'INFO' ("EnableTranscripting=$v (1=enabled)")
}
Safe-Run 'Logging' 'Failed Windows sign-ins in last 24 hours' {
    $events = @(Get-WinEvent -FilterHashtable @{ LogName='Security'; Id=4625; StartTime=(Get-Date).AddHours(-24) } -MaxEvents 100 -ErrorAction Stop)
    Add-Result 'Logging' 'Failed Windows sign-ins in last 24 hours' 'INFO' ("Count of first 100 matching events: $($events.Count). Usernames and event details are not exported.") 'Event count is not exhaustive beyond the first 100; SOC should review detailed events.'
}
Safe-Run 'Policy' 'PowerShell execution policy' {
    $policies = (Get-ExecutionPolicy -List | ForEach-Object { "$($_.Scope)=$($_.ExecutionPolicy)" }) -join '; '
    Add-Result 'Policy' 'PowerShell execution policy' 'INFO' $policies 'Do not bypass a company-enforced execution policy.'
}

# 4. Read-only listening port inventory (LOCAL VM ONLY).
Safe-Run 'Ports' 'Local listening TCP ports' {
    $script:Ports = @(Get-NetTCPConnection -State Listen -ErrorAction Stop |
        Sort-Object LocalPort, LocalAddress |
        Select-Object LocalAddress, LocalPort, OwningProcess)
    $script:Ports | Export-Csv -LiteralPath (Join-Path $OutputDir 'local_listening_tcp_ports.csv') -NoTypeInformation -Encoding UTF8
    Add-Result 'Ports' 'Local listening TCP ports' 'REVIEW' ("Found $($script:Ports.Count) local listening socket(s); details in local_listening_tcp_ports.csv") 'Listening does not establish external exposure; use authorized scans from a separate source.'
    foreach ($p in $script:Ports | Where-Object { $_.LocalPort -in @(22,3389,445,5985,5986,5900,5432,3306) }) {
        Add-Result 'Ports' ("Sensitive service on port $($p.LocalPort)") 'REVIEW' ("LocalAddress=$($p.LocalAddress); PID=$($p.OwningProcess)") 'Confirm service necessity, authentication and network ACLs.'
    }
}

# 5. Tools and Git configuration without exporting credentials.
Safe-Run 'Developer tools' 'Git CLI' {
    Add-Result 'Developer tools' 'Git CLI' 'INFO' (Get-ToolVersion git '--version')
}
Safe-Run 'Developer tools' 'GitHub CLI' {
    Add-Result 'Developer tools' 'GitHub CLI' 'INFO' (Get-ToolVersion gh '--version')
}
Safe-Run 'Developer tools' 'Visual Studio Code CLI' {
    Add-Result 'Developer tools' 'Visual Studio Code CLI' 'INFO' (Get-ToolVersion code '--version')
}
Safe-Run 'Git policy' 'Configured Git credential helper' {
    if (Get-Command git -ErrorAction SilentlyContinue) {
        $helper = (& git config --global --get credential.helper 2>$null | Out-String).Trim()
        if (-not $helper) { $helper = '(none configured in global scope)' }
        Add-Result 'Git policy' 'Configured Git credential helper' 'INFO' $helper 'This does not inspect credentials or tokens.'
    } else { Add-Result 'Git policy' 'Configured Git credential helper' 'UNAVAILABLE' 'Git not installed' }
}
Safe-Run 'Credential hygiene' 'SSH key directory present' {
    $sshDir = Join-Path $env:USERPROFILE '.ssh'
    Add-Result 'Credential hygiene' 'SSH key directory present' 'INFO' (".ssh directory exists: $(Test-Path -LiteralPath $sshDir)") 'Key contents and filenames intentionally not collected.'
}

# 6. Opt-in outbound tests. A direct TCP failure does not rule out a proxy path.
if ($RunEgressChecks) {
    $targets = @(
        @{ Host='github.com'; Port=443; Purpose='GitHub HTTPS' },
        @{ Host='github.com'; Port=22; Purpose='GitHub SSH' },
        @{ Host='ssh.github.com'; Port=443; Purpose='GitHub SSH-over-443 endpoint' },
        @{ Host='api.github.com'; Port=443; Purpose='GitHub REST API' },
        @{ Host='raw.githubusercontent.com'; Port=443; Purpose='GitHub raw files' },
        @{ Host='gist.github.com'; Port=443; Purpose='GitHub Gists' },
        @{ Host='gitlab.com'; Port=443; Purpose='GitLab HTTPS' },
        @{ Host='bitbucket.org'; Port=443; Purpose='Bitbucket HTTPS' }
    )
    if ($EnterpriseGitHost) {
        $targets += @{ Host=$EnterpriseGitHost; Port=443; Purpose='Enterprise Git host' }
    }
    foreach ($target in $targets) {
        $connect = Test-TcpWithTimeout -HostName $target.Host -Port $target.Port
        Add-Result 'Egress TCP' $target.Purpose 'OBSERVED' ("$($target.Host):$($target.Port) -> $connect") 'TCP reachability is not proof of upload permissions or DLP enforcement.'
    }
    foreach ($url in @('https://github.com','https://api.github.com','https://gitlab.com')) {
        try {
            $request = Invoke-WebRequest -Uri $url -Method Head -TimeoutSec 8 -UseBasicParsing -ErrorAction Stop
            Add-Result 'Egress HTTP' $url 'OBSERVED' ("HTTP HEAD status=$([int]$request.StatusCode)") 'HTTP reachability is not an upload test.'
        } catch {
            Add-Result 'Egress HTTP' $url 'OBSERVED' ("HEAD request failed: $($_.Exception.Message)") 'A proxy, HTTP method limitation, authentication, or block may explain failure.'
        }
    }
} else {
    Add-Result 'Egress' 'Outbound network checks' 'NOT_TESTED' 'Opt in with -RunEgressChecks after NOC approval.'
}

# 7. Separate, explicitly authorized synthetic-only GitHub push.
if ($AllowCanaryPush) {
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
        Add-Result 'Canary push' 'Synthetic GitHub push' 'UNAVAILABLE' 'Git CLI not found on PATH.'
    } else {
        $canaryDir = Join-Path $OutputDir 'synthetic_canary_repo'
        try {
            New-Item -ItemType Directory -Path $canaryDir -Force | Out-Null
            $marker = 'SYNTHETIC ONLY - APPROVED RED TEAM CANARY - ' + ([Guid]::NewGuid().ToString())
            Set-Content -LiteralPath (Join-Path $canaryDir 'canary.txt') -Value $marker -Encoding UTF8
            & git -C $canaryDir init -q
            if ($LASTEXITCODE -ne 0) { throw 'git init failed' }
            & git -C $canaryDir add -- canary.txt
            if ($LASTEXITCODE -ne 0) { throw 'git add failed' }
            & git -C $canaryDir -c user.name='VM Red Team Canary' -c user.email='canary@example.invalid' commit -q -m 'Synthetic canary upload security test'
            if ($LASTEXITCODE -ne 0) { throw 'git commit failed' }
            & git -C $canaryDir branch -M main
            if ($LASTEXITCODE -ne 0) { throw 'git branch failed' }
            & git -C $canaryDir remote add origin $CanaryRepoUrl
            if ($LASTEXITCODE -ne 0) { throw 'git remote setup failed' }

            # Noninteractive: existing approved test credentials can be used,
            # but the script will not prompt for, read or print secrets.
            $oldPrompt = $env:GIT_TERMINAL_PROMPT
            $env:GIT_TERMINAL_PROMPT = '0'
            try {
                $null = (& git -C $canaryDir push -u origin main 2>&1 | Out-String)
                $exit = $LASTEXITCODE
            } finally {
                $env:GIT_TERMINAL_PROMPT = $oldPrompt
            }
            if ($exit -eq 0) {
                Add-Result 'Canary push' 'Synthetic GitHub push' 'REVIEW' 'PUSH SUCCEEDED: synthetic canary uploaded to approved non-enterprise test destination.' 'If company policy forbids this, report a confirmed egress control gap to NOC.'
            } else {
                # Avoid exporting full authentication tool text which can contain sensitive URLs.
                Add-Result 'Canary push' 'Synthetic GitHub push' 'OBSERVED' ("Push did not succeed (git exit code $exit). See VM console for diagnostics; no secrets logged.") 'Authentication failure is inconclusive; investigate whether network/security policy actually blocked it.'
                Write-Host "Git push failed. Review the local VM console and approved authentication setup; do not share credentials." -ForegroundColor Yellow
            }
        } catch {
            Add-Result 'Canary push' 'Synthetic GitHub push' 'UNAVAILABLE' $_.Exception.Message 'Check Git setup and NOC-approved destination.'
        }
    }
} else {
    Add-Result 'Canary push' 'Synthetic GitHub push' 'NOT_TESTED' 'Requires both -AllowCanaryPush and -CanaryRepoUrl.'
}

# 8. Manual validation tasks: must not be represented as automated findings.
$manual = @'
AUTHORIZED MANUAL TESTS (not performed automatically)

Obtain explicit NOC/SOC approval and test using synthetic data only.
Document: tester, source VM, target, test time, authentication identity,
expected result, actual result, log/alert reference and remediation.

[ ] Confirm Git HTTPS personal-account push (synthetic only).
[ ] Confirm Git SSH personal-account push (synthetic only).
[ ] Confirm personal-account GitHub website file upload (synthetic only).
[ ] Confirm GitHub API upload using approved test identity and dummy content.
[ ] Confirm VS Code or GitHub CLI personal-account upload restrictions.
[ ] Confirm rules for other Git providers / cloud upload destinations.
[ ] Confirm RDP clipboard: Mac -> VM and VM -> Mac; record policy outcomes.
[ ] Confirm RDP file/drive redirection; do not bypass disabled redirection.
[ ] Confirm MFA, RDP gateway, NLA, account lockout and idle timeout.
[ ] Confirm access for a designated low-privilege test user.
[ ] Review admin memberships and effective GPOs with NOC.
[ ] Confirm exposed RDP/SSH/SMB/WinRM only from intended network segments.
[ ] Perform an authorized vulnerability scan from a separate designated host.
[ ] Confirm endpoint protection, patch status and DLP monitoring with SOC.
[ ] Correlate test events to firewall, proxy, EDR and GitHub audit alerts.
[ ] Retest after NOC implements fixes.

IMPORTANT INTERPRETATION
A TCP/HTTP connection to github.com is not proof of data exfiltration.
A failed git push due to missing credentials is not proof of DLP protection.
Do not upload real source code, company secrets, credentials or reports.
'@
Set-Content -LiteralPath (Join-Path $OutputDir 'manual_test_checklist.txt') -Value $manual -Encoding UTF8

# 9. Final local-only reports.
$csv = Join-Path $OutputDir 'assessment_results.csv'
$json = Join-Path $OutputDir 'assessment_results.json'
$txt = Join-Path $OutputDir 'assessment_summary.txt'
$script:Results | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8
$script:Results | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $json -Encoding UTF8

$byStatus = $script:Results | Group-Object Status | Sort-Object Name
$summaryLines = @(
    'AUTHORIZED VM RED-TEAM BASELINE - LOCAL REPORT'
    ('Generated: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    ('Elapsed: ' + ((Get-Date) - $script:Started).ToString())
    ('Output: ' + $OutputDir)
    ''
    'Counts by status:'
)
foreach ($s in $byStatus) { $summaryLines += ('  {0}: {1}' -f $s.Name, $s.Count) }
$summaryLines += @(
    '',
    'REVIEW and OBSERVED are not automatically vulnerabilities.',
    'UNAVAILABLE means more permission/tooling may be needed.',
    'NOT_TESTED means an opt-in or manual test remains.',
    'No password, token, SSH key contents or company code were collected.',
    'Reports contain VM environment details: do not upload publicly.',
    '',
    'Files:',
    ' - assessment_results.csv (findings and recommendations)',
    ' - assessment_results.json',
    ' - assessment_summary.txt',
    ' - local_listening_tcp_ports.csv (if available)',
    ' - manual_test_checklist.txt'
)
$summaryLines | Set-Content -LiteralPath $txt -Encoding UTF8
Write-Host "`n=== Assessment complete ===" -ForegroundColor Green
$summaryLines | ForEach-Object { Write-Host $_ }
Write-Host "`nOpen results with: explorer.exe `"$OutputDir`"" -ForegroundColor Cyan
